#!/usr/bin/env python3
"""PF233-AB1{A,B} exporter: independent DRC + connectivity check, KiCad .kicad_pcb, Gerbers, drills, STL, previews, BOM, pick&place.
Run:  BOARD=A python3 afe_export.py   (needs out_board/AB1{BOARD}_layout.json from afe_layout.py)"""
import sys, os, json, math, csv, time
import numpy as np
sys.argv = ["x"]
import afe_design as D
import afe_layout as A
import rodin_core_v4 as rc, golden_cone_head as g
B = D.BOARD; OUT = f"kit_v3/PCB_AB1{B}"; os.makedirs(OUT, exist_ok=True)
lay = json.load(open(f"out_board/AB1{B}_layout.json"))
A.PLACE.update({k: tuple(v) for k, v in lay["PLACE"].items()})
PADS = [pd for p in D.PARTS for pd in A.pads_of(p["ref"])]
for pd in PADS: pd["net"] = A.owner.get((pd["ref"], pd["num"]))
NETID = A.NETID; NAMES = {v: k for k, v in NETID.items()}
TR = [(l, tuple(a), tuple(b), w, n) for l, a, b, w, n in lay["TRACKS"]]
VI = [tuple(v) for v in lay["VIAS"]]
def _pad_gap(pd, x, y):
    if pd["tht"]: return math.hypot(x - pd["x"], y - pd["y"]) - pd["w"] / 2
    return max(abs(x - pd["x"]) - pd["w"] / 2, abs(y - pd["y"]) - pd["h"] / 2)
def snap_stubs(TR):
    add = []; seen = set()
    for l, a, b, w, n in TR:
        for e in (a, b):
            for pd in PADS:
                if (NETID.get(pd["net"], 0) if pd["net"] else 0) != n: continue
                if not (pd["tht"] or pd["layer"] == l): continue
                gp = _pad_gap(pd, e[0], e[1])
                if 1e-4 < gp < (0.30 if pd["tht"] else 0.12) and (l, e, pd["ref"], pd["num"]) not in seen:
                    seen.add((l, e, pd["ref"], pd["num"])); add.append((l, tuple(e), (pd["x"], pd["y"]), w, n))
    return add
TR += snap_stubs(TR)

PLANE = {"GND": "In1.Cu", "+5VA": "In4.Cu"}; RL = ["F.Cu", "In2.Cu", "In3.Cu", "B.Cu"]
VIA_D, VIA_DR = A.VIA_D, A.VIA_DRILL; R_BRD = A.R_BOARD
CX, CY = 100.0, 100.0
# ------------------------------------------------------------ items for DRC / connectivity
items = []
for k, pd in enumerate(PADS):
    ls = RL if pd["tht"] else [pd["layer"]]
    shape = ("circle", pd["x"], pd["y"], pd["w"] / 2) if pd["tht"] else ("rect", pd["x"], pd["y"], pd["w"] / 2, pd["h"] / 2)
    items.append(dict(kind="pad", layers=ls, shape=shape, net=NETID.get(pd["net"], 0) if pd["net"] else 0, label=f"{pd['ref']}.{pd['num']}", tht=pd["tht"]))
for l, a, b, w, n in TR: items.append(dict(kind="trk", layers=[l], shape=("seg", a[0], a[1], b[0], b[1], w / 2), net=n, label="trk"))
for x, y, n in VI: items.append(dict(kind="via", layers=RL, shape=("circle", x, y, VIA_D / 2), net=n, label="via"))
def psd(px, py, x0, y0, x1, y1):
    dx, dy = x1 - x0, y1 - y0; L2 = dx * dx + dy * dy
    t = 0.0 if L2 == 0 else max(0.0, min(1.0, ((px - x0) * dx + (py - y0) * dy) / L2)); return math.hypot(px - (x0 + t * dx), py - (y0 + t * dy))
def seg_seg(a, b):
    ax0, ay0, ax1, ay1 = a; bx0, by0, bx1, by1 = b
    def cr(o, p, q): return (p[0] - o[0]) * (q[1] - o[1]) - (p[1] - o[1]) * (q[0] - o[0])
    if cr((ax0, ay0), (ax1, ay1), (bx0, by0)) * cr((ax0, ay0), (ax1, ay1), (bx1, by1)) < 0 and cr((bx0, by0), (bx1, by1), (ax0, ay0)) * cr((bx0, by0), (bx1, by1), (ax1, ay1)) < 0: return 0.0
    return min(psd(ax0, ay0, bx0, by0, bx1, by1), psd(ax1, ay1, bx0, by0, bx1, by1), psd(bx0, by0, ax0, ay0, ax1, ay1), psd(bx1, by1, ax0, ay0, ax1, ay1))
def pt_rect(px, py, r):
    cx, cy, hw, hh = r; dx = max(abs(px - cx) - hw, 0); dy = max(abs(py - cy) - hh, 0); return math.hypot(dx, dy)
def gap(s1, s2):
    if s1[0] > s2[0] or (s1[0] == s2[0] == "rect" and False): pass
    k1, k2 = s1[0], s2[0]
    if k1 == "circle" and k2 == "circle": return math.hypot(s1[1] - s2[1], s1[2] - s2[2]) - s1[3] - s2[3]
    if k1 == "circle" and k2 == "rect": return pt_rect(s1[1], s1[2], s2[1:]) - s1[3]
    if k1 == "rect" and k2 == "circle": return gap(s2, s1)
    if k1 == "rect" and k2 == "rect":
        dx = abs(s1[1] - s2[1]) - s1[3] - s2[3]; dy = abs(s1[2] - s2[2]) - s1[4] - s2[4]
        return math.hypot(max(dx, 0), max(dy, 0)) if (dx > 0 and dy > 0) else max(dx, dy)
    if k1 == "seg" and k2 == "seg": return seg_seg(s1[1:5], s2[1:5]) - s1[5] - s2[5]
    if k1 == "seg" and k2 == "circle": return psd(s2[1], s2[2], *s1[1:5]) - s1[5] - s2[3]
    if k1 == "circle" and k2 == "seg": return gap(s2, s1)
    if k1 == "seg" and k2 == "rect":
        L = math.hypot(s1[3] - s1[1], s1[4] - s1[2]); n = max(2, int(L / 0.03)); best = 1e9
        for i in range(n + 1):
            t = i / n; best = min(best, pt_rect(s1[1] + t * (s1[3] - s1[1]), s1[2] + t * (s1[4] - s1[2]), s2[1:]))
        return best - s1[5]
    if k1 == "rect" and k2 == "seg": return gap(s2, s1)
def bbox(sh):
    if sh[0] == "circle": return sh[1] - sh[3], sh[2] - sh[3], sh[1] + sh[3], sh[2] + sh[3]
    if sh[0] == "rect": return sh[1] - sh[3], sh[2] - sh[4], sh[1] + sh[3], sh[2] + sh[4]
    return min(sh[1], sh[3]) - sh[5], min(sh[2], sh[4]) - sh[5], max(sh[1], sh[3]) + sh[5], max(sh[2], sh[4]) + sh[5]
def check():
    t0 = time.time(); cell = 1.0; grid = {}
    for i, it in enumerate(items):
        x0, y0, x1, y1 = bbox(it["shape"])
        for cx in range(int(math.floor(x0 - 0.2)), int(math.floor(x1 + 0.2)) + 1):
            for cy in range(int(math.floor(y0 - 0.2)), int(math.floor(y1 + 0.2)) + 1): grid.setdefault((cx, cy), []).append(i)
    parent = list(range(len(items)))
    def find(a):
        while parent[a] != a: parent[a] = parent[parent[a]]; a = parent[a]
        return a
    def union(a, b): parent[find(a)] = find(b)
    seen = set(); viol = []; shorts = []; mingap = 9.0; hist = {}
    for lst in grid.values():
        for ii in range(len(lst)):
            for jj in range(ii + 1, len(lst)):
                a, b = lst[ii], lst[jj]
                if (a, b) in seen: continue
                seen.add((a, b)); ia, ib = items[a], items[b]
                if not (set(ia["layers"]) & set(ib["layers"])): continue
                gp = gap(ia["shape"], ib["shape"])
                if ia["net"] == ib["net"] and ia["net"] != 0:
                    if gp <= 0.001: union(a, b)
                    continue
                if ia["kind"] == "pad" and ib["kind"] == "pad" and ia["label"].split(".")[0] == ib["label"].split(".")[0]: continue
                if gp < 0: shorts.append((ia["label"], ib["label"], round(gp, 3)))
                if gp < 0.09: viol.append((ia["label"], ib["label"], round(gp, 3), ia["layers"][0]))
                mingap = min(mingap, gp)
    # plane nodes
    plane_node = {}
    for i, it in enumerate(items):
        n = it["net"]
        if NAMES.get(n) in PLANE and (it["kind"] == "via" or it.get("tht")):
            plane_node.setdefault(n, i); union(i, plane_node[n])
    opens = []
    for name, pins in D.NETS.items():
        ids = [i for i, it in enumerate(items) if it["kind"] == "pad" and it["net"] == NETID[name]]
        if len(ids) < 2: continue
        comps = {}
        for i in ids: comps.setdefault(find(i), []).append(items[i]["label"])
        if len(comps) > 1: opens.append((name, sorted(comps.values(), key=len)[:-1]))
    return dict(clearance_violations_below_0p09=len(viol), min_gap_mm=round(mingap, 4), shorts=len(shorts), short_list=shorts[:10], viol_list=viol[:10],
                nets_with_opens=len(opens), opens=[(n, c) for n, c in opens], time_s=round(time.time() - t0, 1))
DRC = check(); print(json.dumps({k: v for k, v in DRC.items() if k != "opens"}, indent=1)); print("OPENS:", DRC["opens"])
json.dump(DRC, open(f"{OUT}/PF233-AB1{B}_check.json", "w"), indent=1, default=str)

# ------------------------------------------------------------ KiCad PCB
def K(x, y): return f"{CX + x:.4f} {CY + y:.4f}"
def uniq(a): return list(dict.fromkeys(a))
L = ["(kicad_pcb (version 20221018) (generator \"pf233_export\")", "  (general (thickness 1.6) (legacy_teardrops no))", '  (paper "A4")', "  (layers",
     '    (0 "F.Cu" signal) (1 "In1.Cu" signal) (2 "In2.Cu" signal) (3 "In3.Cu" signal) (4 "In4.Cu" signal) (31 "B.Cu" signal)',
     '    (32 "B.Adhes" user "B.Adhesive") (33 "F.Adhes" user "F.Adhesive") (34 "B.Paste" user) (35 "F.Paste" user) (36 "B.SilkS" user "B.Silkscreen") (37 "F.SilkS" user "F.Silkscreen")',
     '    (38 "B.Mask" user) (39 "F.Mask" user) (40 "Dwgs.User" user "User.Drawings") (41 "Cmts.User" user "User.Comments") (44 "Edge.Cuts" user) (45 "Margin" user)',
     '    (46 "B.CrtYd" user "B.Courtyard") (47 "F.CrtYd" user "F.Courtyard") (48 "B.Fab" user) (49 "F.Fab" user))',
     "  (setup (pad_to_mask_clearance 0.05) (stackup (layer \"F.Cu\" (type \"copper\") (thickness 0.035)) (layer \"dielectric 1\" (type \"prepreg\") (thickness 0.2) (material \"FR4\") (epsilon_r 4.5) (loss_tangent 0.02))"
     " (layer \"In1.Cu\" (type \"copper\") (thickness 0.035)) (layer \"dielectric 2\" (type \"core\") (thickness 0.4) (material \"FR4\") (epsilon_r 4.5) (loss_tangent 0.02))"
     " (layer \"In2.Cu\" (type \"copper\") (thickness 0.035)) (layer \"dielectric 3\" (type \"prepreg\") (thickness 0.2) (material \"FR4\") (epsilon_r 4.5) (loss_tangent 0.02))"
     " (layer \"In3.Cu\" (type \"copper\") (thickness 0.035)) (layer \"dielectric 4\" (type \"core\") (thickness 0.4) (material \"FR4\") (epsilon_r 4.5) (loss_tangent 0.02))"
     " (layer \"In4.Cu\" (type \"copper\") (thickness 0.035)) (layer \"dielectric 5\" (type \"prepreg\") (thickness 0.2) (material \"FR4\") (epsilon_r 4.5) (loss_tangent 0.02))"
     " (layer \"B.Cu\" (type \"copper\") (thickness 0.035)) (copper_finish \"ENIG\")))", '  (net 0 "")']
for n, i in sorted(NETID.items(), key=lambda t: t[1]): L.append(f'  (net {i} "{n}")')
for p in D.PARTS:
    ref = p["ref"]; lib = D.LIB[p["type"]]; x0, y0, rot, side = A.PLACE[ref]; lay_ = "F.Cu" if side == "F" else "B.Cu"; sk = "F.SilkS" if side == "F" else "B.SilkS"
    L.append(f'  (footprint "{lib["fp"]}" (layer "{lay_}") (at {K(x0, y0)})')
    L.append(f'    (property "Reference" "{ref}" (at 0 -2.2 0) (layer "{sk}") (effects (font (size 0.7 0.7) (thickness 0.12))))')
    L.append(f'    (property "Value" "{p["value"]}" (at 0 2.2 0) (layer "{"F.Fab" if side == "F" else "B.Fab"}") (effects (font (size 0.7 0.7) (thickness 0.12))))')
    L.append(f'    (attr {"through_hole" if lib.get("tht") else "smd"})')
    for pd in [q for q in PADS if q["ref"] == ref]:
        net = NETID.get(pd["net"], 0) if pd["net"] else 0; nm = pd["net"] or ""
        lx, ly = pd["x"] - x0, pd["y"] - y0
        if pd["tht"]: L.append(f'    (pad "{pd["num"]}" thru_hole circle (at {lx:.4f} {ly:.4f}) (size {pd["w"]} {pd["h"]}) (drill {pd["drill"]}) (layers "*.Cu" "*.Mask") (net {net} "{nm}"))')
        else:
            cu = "F.Cu" if pd["layer"] == "F.Cu" else "B.Cu"; mk = "F" if cu == "F.Cu" else "B"
            L.append(f'    (pad "{pd["num"]}" smd roundrect (at {lx:.4f} {ly:.4f}) (size {pd["w"]:.3f} {pd["h"]:.3f}) (layers "{cu}" "{mk}.Paste" "{mk}.Mask") (roundrect_rratio 0.2) (net {net} "{nm}"))')
    L.append("  )")
for l, a, b, w, n in TR:
    if math.hypot(b[0] - a[0], b[1] - a[1]) < 1e-6: continue
    L.append(f'  (segment (start {K(*a)}) (end {K(*b)}) (width {w:.3f}) (layer "{l}") (net {n}))')
for x, y, n in VI: L.append(f'  (via (at {K(x, y)}) (size {VIA_D}) (drill {VIA_DR}) (layers "F.Cu" "B.Cu") (net {n}))')
L.append(f'  (gr_circle (center {CX} {CY}) (end {CX + R_BRD} {CY}) (stroke (width 0.1) (type default)) (fill none) (layer "Edge.Cuts"))')
pts = " ".join(f"(xy {CX + (R_BRD - 0.3) * math.cos(t):.3f} {CY + (R_BRD - 0.3) * math.sin(t):.3f})" for t in np.linspace(0, 2 * math.pi, 96, endpoint=False))
for nm, lyr in PLANE.items():
    L.append(f'  (zone (net {NETID[nm]}) (net_name "{nm}") (layer "{lyr}") (hatch edge 0.5) (connect_pads (clearance 0.2)) (min_thickness 0.2) (fill yes (thermal_gap 0.25) (thermal_bridge_width 0.3)) (polygon (pts {pts})))')
L.append(")")
open(f"{OUT}/PF233-AB1{B}.kicad_pcb", "w").write("\n".join(L))
bal = sum(l.count("(") - l.count(")") for l in L); print("kicad_pcb paren balance:", bal)
D.kicad_netlist(f"{OUT}/PF233-AB1{B}.net")
with open(f"{OUT}/PF233-AB1{B}_BOM.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(["Qty", "Refs", "Type", "Value", "MPN", "Footprint"])
    for r in D.bom(): w.writerow([r["qty"], r["refs"], r["type"], r["value"], r["mpn"], r["footprint"]])
with open(f"{OUT}/PF233-AB1{B}_pickplace.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(["Ref", "Val", "Package", "PosX_mm", "PosY_mm", "Rot", "Side"])
    for p in D.PARTS: x0, y0, rot, side = A.PLACE[p["ref"]]; w.writerow([p["ref"], p["value"], D.LIB[p["type"]]["fp"].split(":")[1], round(x0, 3), round(-y0, 3), rot, "top" if side == "F" else "bottom"])

# ------------------------------------------------------------ Gerber / Excellon
def gfmt(v): return "%d" % round(v * 1e6)
class Gerber:
    def __init__(self, name): self.name = name; self.ap = {}; self.body = []
    def aperture(self, kind, *sz):
        key = (kind, sz)
        if key not in self.ap: self.ap[key] = 10 + len(self.ap)
        return self.ap[key]
    def sel(self, a): self.body.append(f"D{a}*")
    def flash(self, a, x, y): self.sel(a); self.body.append(f"X{gfmt(x)}Y{gfmt(-y)}D03*")
    def draw(self, a, x0, y0, x1, y1): self.sel(a); self.body.append(f"X{gfmt(x0)}Y{gfmt(-y0)}D02*"); self.body.append(f"X{gfmt(x1)}Y{gfmt(-y1)}D01*")
    def write(self, path):
        h = [f"G04 {self.name}*", "%FSLAX46Y46*%", "%MOMM*%", "%LPD*%"]
        for (kind, sz), n in self.ap.items(): h.append(f"%ADD{n}{'C,' if kind == 'C' else 'R,'}{'X'.join('%.4f' % s for s in sz)}*%")
        open(path, "w").write("\n".join(h + ["G01*"] + self.body + ["M02*"]))
def pad_flash(gb, pd, grow=0.0):
    if pd["tht"]: gb.flash(gb.aperture("C", pd["w"] + grow), pd["x"], pd["y"])
    else: gb.flash(gb.aperture("R", pd["w"] + grow, pd["h"] + grow), pd["x"], pd["y"])
def copper(name, rl):
    gb = Gerber(name)
    for pd in PADS:
        if pd["tht"] or pd["layer"] == rl: pad_flash(gb, pd)
    for l, a, b, w, n in TR:
        if l == rl and math.hypot(b[0] - a[0], b[1] - a[1]) > 1e-6: gb.draw(gb.aperture("C", w), a[0], a[1], b[0], b[1])
    for x, y, n in VI: gb.flash(gb.aperture("C", VIA_D), x, y)
    gb.write(f"{OUT}/PF233-AB1{B}-{name}.gbr")
def plane(name, netname):
    gb = Gerber(name); gb.body.append("G36*"); R_ = R_BRD - 0.3
    pts_ = [(R_ * math.cos(t), R_ * math.sin(t)) for t in np.linspace(0, 2 * math.pi, 181)]
    gb.body.append(f"X{gfmt(pts_[0][0])}Y{gfmt(-pts_[0][1])}D02*"); [gb.body.append(f"X{gfmt(px)}Y{gfmt(-py)}D01*") for px, py in pts_[1:]]; gb.body.append("G37*")
    gb.body.append("%LPC*%")
    for pd in PADS:
        if pd["tht"] and pd["net"] != netname: gb.flash(gb.aperture("C", pd["w"] + 0.5), pd["x"], pd["y"])
    for x, y, n in VI:
        if NAMES.get(n) != netname: gb.flash(gb.aperture("C", VIA_D + 0.5), x, y)
    gb.body.append("%LPD*%")
    for pd in PADS:
        if pd["tht"] and pd["net"] == netname: gb.flash(gb.aperture("C", pd["w"]), pd["x"], pd["y"])
    for x, y, n in VI:
        if NAMES.get(n) == netname: gb.flash(gb.aperture("C", VIA_D), x, y)
    gb.write(f"{OUT}/PF233-AB1{B}-{name}.gbr")
copper("F_Cu", "F.Cu"); copper("In2_Cu", "In2.Cu"); copper("In3_Cu", "In3.Cu"); copper("B_Cu", "B.Cu")
plane("In1_Cu_GND", "GND"); plane("In4_Cu_5VA", "+5VA")
for side, rl in (("F", "F.Cu"), ("B", "B.Cu")):
    mk = Gerber(f"{side}_Mask"); ps = Gerber(f"{side}_Paste")
    for pd in PADS:
        if pd["tht"] or pd["layer"] == rl: pad_flash(mk, pd, 0.1)
        if (not pd["tht"]) and pd["layer"] == rl: pad_flash(ps, pd, -0.05)
    mk.write(f"{OUT}/PF233-AB1{B}-{side}_Mask.gbr"); ps.write(f"{OUT}/PF233-AB1{B}-{side}_Paste.gbr")
ec = Gerber("Edge_Cuts"); a_ = ec.aperture("C", 0.1); pts_ = [(R_BRD * math.cos(t), R_BRD * math.sin(t)) for t in np.linspace(0, 2 * math.pi, 361)]
for (x0, y0), (x1, y1) in zip(pts_[:-1], pts_[1:]): ec.draw(a_, x0, y0, x1, y1)
ec.write(f"{OUT}/PF233-AB1{B}-Edge_Cuts.gbr")
sl = Gerber("F_Silkscreen"); a_ = sl.aperture("C", 0.12)
for p in D.PARTS:
    x0, y0, rot, side = A.PLACE[p["ref"]]
    if side != "F": continue
    bw, bh, _ = D.LIB[p["type"]]["body"]
    if rot % 180 == 90: bw, bh = bh, bw
    c = [(x0 - bw / 2, y0 - bh / 2), (x0 + bw / 2, y0 - bh / 2), (x0 + bw / 2, y0 + bh / 2), (x0 - bw / 2, y0 + bh / 2)]
    for i in range(4): sl.draw(a_, *c[i], *c[(i + 1) % 4])
sl.write(f"{OUT}/PF233-AB1{B}-F_Silkscreen.gbr")
with open(f"{OUT}/PF233-AB1{B}-PTH.drl", "w") as f:
    f.write("M48\nMETRIC,TZ\nT1C%.3f\nT2C%.3f\n%%\nT1\n" % (VIA_DR, 0.65))
    for x, y, n in VI: f.write("X%.3fY%.3f\n" % (x, -y))
    f.write("T2\n")
    for pd in PADS:
        if pd["tht"]: f.write("X%.3fY%.3f\n" % (pd["x"], -pd["y"]))
    f.write("M30\n")
# ------------------------------------------------------------ STL (board + component bodies)
sub = g.revolve([(0.01, -1.6), (R_BRD, -1.6), (R_BRD, 0.0), (0.01, 0.0)], 180)
parts_mesh = [sub]
def boxm(cx, cy, z0, lx, ly, lz):
    x = np.array([-1, 1]) * lx / 2; y = np.array([-1, 1]) * ly / 2
    V = np.array([[a, b, z0 + c * lz] for a in x for b in y for c in (0, 1)]) + [cx, cy, 0]
    F = np.array([[0, 1, 3], [0, 3, 2], [4, 6, 7], [4, 7, 5], [0, 4, 5], [0, 5, 1], [2, 3, 7], [2, 7, 6], [0, 2, 6], [0, 6, 4], [1, 5, 7], [1, 7, 3]])
    return V, (F if rc.signed_volume(V, F) > 0 else F[:, ::-1])
for p in D.PARTS:
    x0, y0, rot, side = A.PLACE[p["ref"]]; bw, bh, bz = D.LIB[p["type"]]["body"]
    if rot % 180 == 90: bw, bh = bh, bw
    if D.LIB[p["type"]].get("tht"): parts_mesh.append(boxm(x0, -y0, 0.0, bw, bh, bz))
    elif side == "F": parts_mesh.append(boxm(x0, -y0, 0.0, bw, bh, bz))
    else: parts_mesh.append(boxm(x0, -y0, -1.6 - bz, bw, bh, bz))
for l, a, b, w, n in TR:
    pass
Vs, Fs = g.merge(parts_mesh); rc.write_stl(f"{OUT}/PF233-AB1{B}_board_with_components.stl", Vs, Fs, "ab1")
# ------------------------------------------------------------ previews
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
fig, axs = plt.subplots(1, 2, figsize=(16, 8.2)); col = {"F.Cu": "#c0392b", "In2.Cu": "#27ae60", "In3.Cu": "#2980b9", "B.Cu": "#8e44ad"}
for ax, view in zip(axs, ("F", "B")):
    ax.add_patch(plt.Circle((0, 0), R_BRD, fc="#0b3d2e", ec="w", lw=1)); ax.set_aspect("equal"); ax.set_xlim(-21, 21); ax.set_ylim(21, -21)
    for l, a, b, w, n in TR:
        if (view == "F" and l in ("F.Cu", "In2.Cu")) or (view == "B" and l in ("B.Cu", "In3.Cu")): ax.plot([a[0], b[0]], [a[1], b[1]], color=col[l], lw=max(w * 4, 0.7), alpha=0.9 if l in ("F.Cu", "B.Cu") else 0.5, solid_capstyle="round")
    for x, y, n in VI: ax.add_patch(plt.Circle((x, y), VIA_D / 2, fc="#f1c40f", ec="k", lw=0.2))
    for pd in PADS:
        if pd["tht"] or (view == "F") == (pd["layer"] == "F.Cu"): ax.add_patch(plt.Rectangle((pd["x"] - pd["w"] / 2, pd["y"] - pd["h"] / 2), pd["w"], pd["h"], fc="#ecf0f1", ec="k", lw=0.2))
    for p in D.PARTS:
        x0, y0, rot, side = A.PLACE[p["ref"]]
        if (side == "F") == (view == "F") or D.LIB[p["type"]].get("tht"): ax.text(x0, y0, p["ref"], color="w", fontsize=5.5, ha="center", va="center")
    ax.set_title(f"PF233-AB1{B}  {'TOP (F.Cu red, In2 green)' if view == 'F' else 'BOTTOM (B.Cu purple, In3 blue) - mirrored x not applied'}", fontsize=9)
fig.tight_layout(); fig.savefig(f"{OUT}/PF233-AB1{B}_layout_preview.png", dpi=130)
print("exported", OUT, len(items), "items")
