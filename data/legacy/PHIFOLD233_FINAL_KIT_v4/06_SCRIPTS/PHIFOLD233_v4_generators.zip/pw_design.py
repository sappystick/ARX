#!/usr/bin/env python3
"""
PF233-PM1 (battery power path / protection / hot-swap OR-ing)  and  PF233-PB1 (TX driver power stage) design database.
Select with env PW=M (PM1) or PW=T (PB1).  API mirrors afe_design (PARTS, NETS, LIB, BYREF, erc(), bom(), kicad_netlist()).
Pin maps / land patterns for ICs and power packages are from memory -> VERIFY list in the build report.
"""
import os, datetime
PW = os.environ.get("PW", "M"); BOARD = PW; CH = []
def pads2(dx, w, h, shape="roundrect"): return [("1", -dx, 0, w, h, shape), ("2", dx, 0, w, h, shape)]
def pair(desc, fp, dx, w, h, body, names=("1", "2"), types=("passive", "passive")):
    return dict(desc=desc, fp=fp, pins=[("1", names[0], types[0]), ("2", names[1], types[1])], pads=pads2(dx, w, h), body=body)
def tht(n, pitch, rows=1, dia=1.7, drill=1.0, desc="header"):
    pins = [(str(i + 1), str(i + 1), "passive") for i in range(n * rows)]; pads = []
    for i in range(n * rows):
        if rows == 1: x, y = 0.0, (i - (n - 1) / 2) * pitch
        else: k, c = divmod(i, 2); x, y = (c - 0.5) * pitch, (k - (n - 1) / 2) * pitch
        pads.append((str(i + 1), x, y, dia, dia, "circle"))
    return dict(desc=f"{desc} {rows}x{n} pitch {pitch}", fp=f"Connector:{desc.replace(' ', '_')}_{rows}x{n}_P{pitch}mm", pins=pins, pads=pads, body=(rows * pitch + 1.5, n * pitch + 1.5, 9.0), tht=True, drill=drill)
LIB = {
 "R0603": pair("Resistor 0603", "Resistor_SMD:R_0603_1608Metric", 0.825, 0.8, 0.95, (1.6, 0.8, 0.5)),
 "R1206": pair("Resistor 1206", "Resistor_SMD:R_1206_3216Metric", 1.5, 1.2, 1.8, (3.2, 1.6, 0.6)),
 "R2512": pair("Resistor 2512 (1-3 W)", "Resistor_SMD:R_2512_6332Metric", 3.1, 1.6, 3.4, (6.3, 3.2, 0.7)),
 "C0603": pair("Capacitor 0603", "Capacitor_SMD:C_0603_1608Metric", 0.775, 0.8, 0.95, (1.6, 0.8, 0.8)),
 "C0805": pair("Capacitor 0805", "Capacitor_SMD:C_0805_2012Metric", 0.95, 1.0, 1.45, (2.0, 1.25, 1.0)),
 "C1210": pair("Capacitor 1210", "Capacitor_SMD:C_1210_3225Metric", 1.5, 1.2, 2.7, (3.2, 2.5, 2.0)),
 "CAN10": pair("SMD aluminium/hybrid can 10x10", "Capacitor_SMD:CP_Elec_10x10", 4.4, 4.0, 2.6, (10.3, 10.3, 10.5), ("+", "-")),
 "FUSE1812": pair("SMD fuse 1812 (6.1x2.7)", "Fuse:Fuse_1812_4532Metric", 2.9, 2.0, 3.4, (4.5, 3.2, 1.8)),
 "DSMC": pair("Diode SMC (DO-214AB)", "Diode_SMD:D_SMC", 3.4, 2.4, 3.4, (7.1, 6.1, 2.4), ("K", "A")),
 "DSMB": pair("Diode SMB (DO-214AA)", "Diode_SMD:D_SMB", 2.2, 2.0, 2.4, (4.6, 3.6, 2.4), ("K", "A")),
 "DSOD": pair("Signal diode SOD-123", "Diode_SMD:D_SOD-123", 1.35, 0.9, 1.2, (2.7, 1.6, 1.1), ("K", "A")),
 "FB1812": pair("Ferrite bead 1812 (>=6 A)", "Inductor_SMD:L_1812_4532Metric", 2.9, 2.0, 3.4, (4.5, 3.2, 2.5)),
 "WIRE2": dict(desc="two solder pads for an external power resistor (wire/lug), 5.08 mm", fp="Connector:SolderPad_2x_P5.08mm", pins=[("1", "1", "passive"), ("2", "2", "passive")],
               pads=[("1", -2.54, 0, 3.0, 3.0, "circle"), ("2", 2.54, 0, 3.0, 3.0, "circle")], body=(8.0, 3.5, 3.0), tht=True, drill=1.6),
 "TERM4": tht(4, 5.08, 1, 3.0, 1.7, "Terminal block"), "TERM2": tht(2, 5.08, 1, 3.0, 1.7, "Terminal block"),
 "HDR1x3": tht(3, 2.54, 1, 1.8, 1.0, "Pin header"), "HDR1x2": tht(2, 2.54, 1, 1.8, 1.0, "Pin header"),
 "HDR2x4": tht(4, 2.54, 2, 1.8, 1.0, "Pin header"), "HDR2x6": tht(6, 2.54, 2, 1.8, 1.0, "Pin header"),
 "D2PAK": dict(desc="MOSFET TO-263-3 (D2PAK) G-D-S, tab = drain (VERIFY land pattern)", fp="Package_TO_SOT_SMD:TO-263-3_TabPin2",
               pins=[("1", "G", "input"), ("2", "D", "passive"), ("3", "S", "passive")],
               pads=[("1", -6.8, -2.54, 3.0, 1.6, "roundrect"), ("3", -6.8, 2.54, 3.0, 1.6, "roundrect"), ("2", 2.4, 0, 9.4, 10.8, "rect")], body=(10.2, 9.2, 4.6)),
 "SOIC8": None,
}
_soic_pads = [("1", -2.7, -1.905, 1.55, 0.6, "roundrect"), ("2", -2.7, -0.635, 1.55, 0.6, "roundrect"), ("3", -2.7, 0.635, 1.55, 0.6, "roundrect"), ("4", -2.7, 1.905, 1.55, 0.6, "roundrect"),
              ("5", 2.7, 1.905, 1.55, 0.6, "roundrect"), ("6", 2.7, 0.635, 1.55, 0.6, "roundrect"), ("7", 2.7, -0.635, 1.55, 0.6, "roundrect"), ("8", 2.7, -1.905, 1.55, 0.6, "roundrect")]
LIB["TC4420"] = dict(desc="TC4420 6 A MOSFET driver SOIC-8 (VERIFY pinout)", fp="Package_SO:SOIC-8_3.9x4.9mm_P1.27mm",
    pins=[("1", "VDD", "power_in"), ("2", "IN", "input"), ("3", "NC", "no_connect"), ("4", "GND", "power_in"), ("5", "GND2", "power_in"), ("6", "OUT", "output"), ("7", "OUT2", "output"), ("8", "VDD2", "power_in")],
    pads=_soic_pads, body=(4.9, 3.9, 1.6))
LIB["LM393"] = dict(desc="LM393 dual comparator SOIC-8", fp="Package_SO:SOIC-8_3.9x4.9mm_P1.27mm",
    pins=[("1", "OUT_A", "output"), ("2", "IN-_A", "input"), ("3", "IN+_A", "input"), ("4", "GND", "power_in"), ("5", "IN+_B", "input"), ("6", "IN-_B", "input"), ("7", "OUT_B", "output"), ("8", "VCC", "power_in")],
    pads=_soic_pads, body=(4.9, 3.9, 1.6))
del LIB["SOIC8"]
PARTS = []; NETS = {}
def add(ref, typ, value, mpn="", **kw): PARTS.append(dict(ref=ref, type=typ, value=value, mpn=mpn, **kw))
def net(name, *pins):
    NETS.setdefault(name, [])
    for p in pins: NETS[name].append((p[0], str(p[1])))
if PW == "M":
    # ------------------------------------------------------------------ PM1: two cartridge inputs, fuse, precharge, OR-ing, TVS, bulk, aux, sense, outputs
    for X in "AB":
        add(f"J{X}", "TERM4", f"Cartridge {X}: NEG, PRE, POS, ID", "5.08 mm blade-contact block (see shaft design)")
        add(f"F{X}", "FUSE1812", "5A slow 32V", "Littelfuse 0453005 class (verify DC rating)")
        add(f"DO{X}", "DSMC", "SS10P6 60V 10A", "Schottky SMC 60 V 10 A")
        add(f"RP{X}", "R2512", "22R 2W pulse", "Vishay CRCW-HP / KOA SR732 class")
        add(f"DP{X}", "DSMB", "SS3P6 60V 3A", "Schottky SMB 60 V 3 A")
        net("GND", (f"J{X}", 1)); net(f"{X}_PRE", (f"J{X}", 2), (f"RP{X}", 1)); net(f"{X}_PM", (f"RP{X}", 2), (f"DP{X}", 2))
        net(f"{X}_POS", (f"J{X}", 3), (f"F{X}", 1)); net(f"{X}_FO", (f"F{X}", 2), (f"DO{X}", 2))
        net("VBUS", (f"DO{X}", 1), (f"DP{X}", 1)); net(f"{X}_ID", (f"J{X}", 4))
    add("DTVS", "DSMC", "SMCJ33A", "TVS 33 V stand-off, uni-directional"); net("VBUS", ("DTVS", 1)); net("GND", ("DTVS", 2))
    for n in (1, 2): add(f"CB{n}", "CAN10", "470u 50V", "hybrid polymer/Al 10x10, low ESR"); net("VBUS", (f"CB{n}", 1)); net("GND", (f"CB{n}", 2))
    for n in (1, 2): add(f"CM{n}", "C1210", "10u 50V", "X7R"); net("VBUS", (f"CM{n}", 1)); net("GND", (f"CM{n}", 2))
    add("RBL", "R1206", "100k", "bleeder"); net("VBUS", ("RBL", 1)); net("GND", ("RBL", 2))
    add("RS1", "R0603", "100k", "0.1%"); add("RS2", "R0603", "10k", "0.1%"); add("CS1", "C0603", "100n", "X7R 50V")
    net("VBUS", ("RS1", 1)); net("BUS_SENSE", ("RS1", 2), ("RS2", 1), ("CS1", 1)); net("GND", ("RS2", 2), ("CS1", 2))
    add("JBK", "HDR1x3", "Aux buck module VIN GND VOUT", "COTS 36 V -> 12 V >= 1.5 A buck module (e.g. Pololu D36V28F12 class)")
    net("VBUS", ("JBK", 1)); net("GND", ("JBK", 2)); net("BUCK_OUT", ("JBK", 3), ("FB1", 1))
    add("FB1", "FB1812", "BLM/742792 class 6A", "ferrite bead"); add("CAUX", "C1210", "22u 25V", "X7R"); add("CAUX2", "C0603", "100n", "X7R")
    net("AUX12", ("FB1", 2), ("CAUX", 1), ("CAUX2", 1)); net("GND", ("CAUX", 2), ("CAUX2", 2))
    add("JP", "TERM4", "Power out: VBUS VBUS GND GND", "5.08 mm terminal block 10 A"); net("VBUS", ("JP", 1), ("JP", 2)); net("GND", ("JP", 3), ("JP", 4))
    add("JS", "HDR2x4", "Signals: 12V GND 485A 485B SENSE A_ID B_ID SHLD", "2.54 mm header")
    net("AUX12", ("JS", 1)); net("GND", ("JS", 2)); net("RS485_A", ("JS", 3), ("JR", 1)); net("RS485_B", ("JS", 4), ("JR", 2)); net("BUS_SENSE", ("JS", 5))
    net("A_ID", ("JS", 6)); net("B_ID", ("JS", 7)); add("JR", "HDR1x2", "RS-485 to pod", "2.54 mm header")
    add("RSH", "R0603", "1M", ""); add("CSH", "C0603", "1n 100V", "C0G"); net("SHIELD", ("JS", 8), ("RSH", 1), ("CSH", 1)); net("GND", ("RSH", 2), ("CSH", 2))
else:
    # ------------------------------------------------------------------ PB1: bulk, two TX channels (gate driver, FETs, shunt, clamp, OCP comparator), controller interface
    add("JP", "TERM4", "Power in: VBUS VBUS GND GND", "5.08 mm terminal block 10 A"); net("VBUS", ("JP", 1), ("JP", 2)); net("GND", ("JP", 3), ("JP", 4))
    for n in (1, 2): add(f"CB{n}", "CAN10", "470u 50V", "hybrid polymer, low ESR"); net("VBUS", (f"CB{n}", 1)); net("GND", (f"CB{n}", 2))
    for n in range(1, 5): add(f"CM{n}", "C1210", "10u 50V", "X7R"); net("VBUS", (f"CM{n}", 1)); net("GND", (f"CM{n}", 2))
    add("JC", "HDR2x6", "Controller I/F", "2.54 mm header")
    jc = {1: "AUX12", 2: "GND", 3: "TX1_IN", 4: "TX2_IN", 5: "REF_I1", 6: "REF_I2", 7: "FAULT1_N", 8: "FAULT2_N", 9: "ISENSE1", 10: "ISENSE2", 11: "NTC_SENSE", 12: "GND"}
    for p, nm in jc.items(): net(nm, ("JC", p))
    add("RNTC", "R0603", "10k NTC", "NTC thermistor (on FET heat spreader)"); net("NTC_SENSE", ("RNTC", 1)); net("GND", ("RNTC", 2))
    add("U3", "LM393", "LM393", "TI LM393DR"); add("CU3", "C0805", "1u 25V", "X7R"); net("AUX12", ("U3", 8), ("CU3", 1)); net("GND", ("U3", 4), ("CU3", 2))
    CHANNELS = [dict(n=1, Qs=["Q1A", "Q1B"], Dc="DC1", dtype="DSMC", dval="ES3J 600V 3A", vtype="C1210", cl=["CL1A", "CL1B"], clv="100n 630V", rs="RS1S", rsval="10m 3W", half="A", coil="JL1"),
                 dict(n=2, Qs=["Q2A"], Dc="DC2", dtype="DSMB", dval="ES2D 200V 2A", vtype="C1210", cl=["CL2A"], clv="1u 100V", rs="RS2S", rsval="10m 3W", half="B", coil="JL2")]
    for c in CHANNELS:
        n = c["n"]; U = f"U{n}"
        add(U, "TC4420", "TC4420", "Microchip TC4420"); add(f"CD{n}", "C0805", "1u 25V", "X7R"); add(f"CE{n}", "C0603", "100n", "X7R")
        net("AUX12", (U, 1), (U, 8), (f"CD{n}", 1), (f"CE{n}", 1)); net("GND", (U, 4), (U, 5), (f"CD{n}", 2), (f"CE{n}", 2)); net(f"DRV{n}_NC", (U, 3))
        add(f"RIN{n}", "R0603", "100", ""); net(f"TX{n}_IN", (f"RIN{n}", 1)); net(f"DRVIN{n}", (f"RIN{n}", 2), (U, 2), (f"DOC{n}", 2))
        add(f"DOC{n}", "DSOD", "BAS16", "signal diode"); net(f"OC{n}_OUT", (f"DOC{n}", 1))
        net(f"G{n}", (U, 6), (U, 7)); add(f"RGP{n}", "R0603", "10k", ""); net(f"G{n}", (f"RGP{n}", 1)); net("GND", (f"RGP{n}", 2))
        for q in c["Qs"]:
            add(q, "D2PAK", "650V SJ 95mR" if n == 1 else "100V 10mR", "IPB65R095C7 class" if n == 1 else "100 V D2PAK, Rds(on) <= 10 mohm")
            add(f"RG{q}", "R0603", "10", ""); net(f"G{n}", (f"RG{q}", 1)); net(f"GATE_{q}", (f"RG{q}", 2), (q, 1))
            net(f"DRAIN{n}", (q, 2)); net(f"SRC{n}", (q, 3))
        add(c["rs"], "R2512", c["rsval"], "Kelvin-capable 2512 shunt, 3 W")
        net(f"SRC{n}", (c["rs"], 1)); net("GND", (c["rs"], 2))
        add(c["Dc"], c["dtype"], c["dval"], "ultrafast clamp diode"); net(f"DRAIN{n}", (c["Dc"], 2)); net(f"CLAMP{n}", (c["Dc"], 1))
        for cl in c["cl"]: add(cl, c["vtype"], c["clv"], "C0G/X7R HV"); net(f"CLAMP{n}", (cl, 1)); net("VBUS", (cl, 2))
        add(f"RCL{n}", "WIRE2", "external 5k 10W" if n == 1 else "external 100R 5W", "chassis-mount power resistor on the aluminium spreader"); net(f"CLAMP{n}", (f"RCL{n}", 1)); net("VBUS", (f"RCL{n}", 2))
        add(f"JL{n}", "TERM2", f"Coil {'outer' if n == 1 else 'inner'}: DRAIN, VBUS", "5.08 mm terminal block 10 A"); net(f"DRAIN{n}", (f"JL{n}", 1)); net("VBUS", (f"JL{n}", 2))
        # over-current comparator: IN- = filtered shunt voltage, IN+ = REF_I; output low when sense > ref
        h = c["half"]; inm, inp, out = (2, 3, 1) if h == "A" else (6, 5, 7)
        add(f"RK{n}", "R0603", "100", ""); add(f"CK{n}", "C0603", "100p", "C0G"); add(f"RPU{n}", "R0603", "10k", ""); add(f"RF{n}", "R0603", "1k", "")
        net(f"SRC{n}", (f"RK{n}", 1)); net(f"ISENSE{n}", (f"RK{n}", 2), (f"CK{n}", 1), ("U3", inm)); net("GND", (f"CK{n}", 2))
        net(f"REF_I{n}", ("U3", inp)); net(f"OC{n}_OUT", ("U3", out), (f"RPU{n}", 1), (f"RF{n}", 1)); net("AUX12", (f"RPU{n}", 2)); net(f"FAULT{n}_N", (f"RF{n}", 2))
for k in NETS: NETS[k] = list(dict.fromkeys(NETS[k]))
BYREF = {p["ref"]: p for p in PARTS}
def pin_info(ref, num):
    for n, name, typ in LIB[BYREF[ref]["type"]]["pins"]:
        if str(n) == str(num): return name, typ
    raise KeyError((ref, num))
def erc():
    errs = []; owner = {}
    refs = [p["ref"] for p in PARTS]
    if len(set(refs)) != len(refs): errs.append("duplicate refs")
    for n, pins in NETS.items():
        for pr in pins:
            if pr in owner and owner[pr] != n: errs.append(f"pin {pr} in two nets {owner[pr]} / {n}")
            owner[pr] = n
            try: pin_info(*pr)
            except KeyError: errs.append(f"unknown pin {pr} in {n}")
    for p in PARTS:
        for num, name, typ in LIB[p["type"]]["pins"]:
            if (p["ref"], num) not in owner and typ != "no_connect": errs.append(f"unconnected {p['ref']}.{name}")
    for n, pins in NETS.items():
        if len(pins) < 2 and not n.endswith("_NC") and not n.endswith("_ID"): errs.append(f"single-pin net {n}: {pins}")
    for p in PARTS:
        if p["type"] in ("TC4420", "LM393"):
            sup = "AUX12"; v = [nm for nm, t in ((x[1], x[2]) for x in LIB[p["type"]]["pins"]) if nm in ("VDD", "VDD2", "VCC")]
            for num, name, t in LIB[p["type"]]["pins"]:
                if name in ("VDD", "VDD2", "VCC") and owner.get((p["ref"], num)) != sup: errs.append(f"{p['ref']}.{name} not on {sup}")
                if name in ("GND", "GND2") and owner.get((p["ref"], num)) != "GND": errs.append(f"{p['ref']}.{name} not on GND")
    return errs, []
def bom():
    rows = {}
    for p in PARTS: rows.setdefault((p["type"], p["value"], p["mpn"]), []).append(p["ref"])
    return [dict(qty=len(r), refs=",".join(r), type=k[0], value=k[1], mpn=k[2], footprint=LIB[k[0]]["fp"]) for k, r in sorted(rows.items())]
def kicad_netlist(path):
    L = ['(export (version "E")', f'  (design (source "PF233-{PW}.net") (date "{datetime.date.today()}") (tool "pw_design.py"))', "  (components"]
    for p in PARTS:
        lib = LIB[p["type"]]; L.append(f'    (comp (ref "{p["ref"]}") (value "{p["value"]}") (footprint "{lib["fp"]}") (libsource (lib "PF233") (part "{p["type"]}") (description "{lib["desc"]}")) (property (name "MPN") (value "{p["mpn"]}")))')
    L += ["  )", "  (nets"]
    for i, (n, pins) in enumerate(sorted(NETS.items()), 1):
        L.append(f'    (net (code "{i}") (name "{n}")')
        for ref, num in pins: L.append(f'      (node (ref "{ref}") (pin "{num}") (pinfunction "{pin_info(ref, num)[0]}"))')
        L.append("    )")
    L += ["  )", ")"]; open(path, "w").write("\n".join(L))
if __name__ == "__main__":
    e, w = erc(); print("board", PW, "parts", len(PARTS), "nets", len(NETS), "ERC errors", len(e)); [print(" E:", x) for x in e[:25]]
